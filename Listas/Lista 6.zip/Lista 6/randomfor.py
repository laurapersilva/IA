import pandas as pd
import numpy as np

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, confusion_matrix, precision_score, 
                             recall_score, f1_score, ConfusionMatrixDisplay)
from sklearn.model_selection import train_test_split

from sklearn.tree import export_graphviz
import graphviz
import matplotlib.pyplot as plt

bank_data = pd.read_csv('../base/train.csv') 

# --- Pré-processamento do alvo e da coluna 'default'
bank_data['default'] = bank_data['default'].map({'no': 0, 'yes': 1, 'unknown': 2})  # melhor manter 'unknown' distinto
bank_data['y'] = bank_data['y'].map({'no': 0, 'yes': 1})

X = bank_data.drop('y', axis=1)
y = bank_data['y']

# Split com estratificação e reproducibilidade
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# --- Instanciar e treinar o RandomForest ---
rf = RandomForestClassifier(
    n_estimators=300,
    random_state=42,
    n_jobs=-1
)
rf.fit(X_train, y_train)

y_pred = rf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
prec = precision_score(y_test, y_pred, zero_division=0)
rec = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)

print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {prec:.4f} | Recall: {rec:.4f} | F1: {f1:.4f}")

ConfusionMatrixDisplay.from_predictions(y_test, y_pred, normalize='true')
plt.show()

#Visualização de algumas árvores (requer graphviz instalado no OS) 
n_to_show = min(3, len(rf.estimators_))
for i in range(n_to_show):
    tree = rf.estimators_[i]
    dot = export_graphviz(
        tree,
        feature_names=X_train.columns,
        class_names=['no', 'yes'],
        filled=True,
        max_depth=2,
        impurity=False,
        proportion=True
    )
    graph = graphviz.Source(dot)
    display(graph)
