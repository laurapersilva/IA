import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, ConfusionMatrixDisplay, classification_report

from skopt import BayesSearchCV
from skopt.space import Real

X, y = make_classification(
    n_features=6,
    n_classes=3,
    n_samples=800,
    n_informative=2,
    random_state=1,
    n_clusters_per_class=1,
)

plt.figure(figsize=(5,4))
plt.scatter(X[:, 0], X[:, 1], c=y, marker="*")
plt.title("Dados sintéticos (2 features)")
plt.xlabel("X0")
plt.ylabel("X1")
plt.show()

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.33, random_state=125, stratify=y
)

# --- Baseline (sem otimização) ---
baseline = GaussianNB()
baseline.fit(X_train, y_train)
y_pred_base = baseline.predict(X_test)
acc_base = accuracy_score(y_test, y_pred_base)
f1_base = f1_score(y_test, y_pred_base, average="weighted")
print(f"[Baseline] Accuracy={acc_base:.4f} | F1(w)={f1_base:.4f}")

search_space = {
    "var_smoothing": Real(1e-12, 1e-3, prior="log-uniform")
}

# --- Validação cruzada estratificada ---
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# --- BayesSearchCV ---
bayes_cv = BayesSearchCV(
    estimator=GaussianNB(),
    search_spaces=search_space,
    n_iter=50,               
    cv=cv,
    scoring="f1_weighted",   
    n_jobs=-1,
    random_state=42,
    refit=True,              
    return_train_score=True,
    verbose=0
)

# --- Otimização ---
bayes_cv.fit(X_train, y_train)

print("\nMelhores hiperparâmetros encontrados:", bayes_cv.best_params_)
print(f"Melhor F1(w) em CV: {bayes_cv.best_score_:.4f}")

best_model = bayes_cv.best_estimator_
y_pred = best_model.predict(X_test)

acc = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred, average="weighted")

print(f"[BayesSearchCV] Accuracy={acc:.4f} | F1(w)={f1:.4f}")
print("\nClassification Report (teste):\n", classification_report(y_test, y_pred))

# --- Matriz de confusão ---
labels = best_model.classes_  # mais seguro do que fixar [0,1,2]
cm = confusion_matrix(y_test, y_pred, labels=labels)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
disp.plot(cmap="Blues", values_format="d")
plt.title("Matriz de Confusão - GaussianNB (BayesSearchCV)")
plt.show()

# --- Predição de um único exemplo ---
single_pred = best_model.predict(X_test[[6]])
print("\nValor real:     ", y_test[6])
print("Valor previsto: ", single_pred[0])
