import pandas as pd
from sklearn.datasets import make_classification
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    ConfusionMatrixDisplay,
    f1_score,
    classification_report
)

df = pd.read_csv('../base/train.csv')
print(df.head())

# Dados sintéticos para exemplo
X, y = make_classification(
    n_features=6,
    n_classes=3,
    n_samples=800,
    n_informative=2,
    random_state=1,
    n_clusters_per_class=1,
)

# Visualização rápida (apenas 2 primeiras features)
plt.figure(figsize=(5,4))
plt.scatter(X[:, 0], X[:, 1], c=y, marker="*")
plt.title("Dados sintéticos (2 features)")
plt.xlabel("X0")
plt.ylabel("X1")
plt.show()

# Split (com estratificação)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.33, random_state=125, stratify=y
)

# Modelo Gaussian Naive Bayes
model = GaussianNB()

# Treinamento
model.fit(X_train, y_train)

# Predição de um único exemplo (forma 2D)
single_pred = model.predict(X_test[[6]])
print("Valor real:     ", y_test[6])
print("Valor previsto: ", single_pred[0])

# Predição geral
y_pred = model.predict(X_test)

# ✅ Ordem correta: (y_true, y_pred)
accuracy = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred, average="weighted")

print("Accuracy:", accuracy)
print("F1 (weighted):", f1)
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# Matriz de confusão (usando classes do modelo)
labels = model.classes_
cm = confusion_matrix(y_test, y_pred, labels=labels)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
disp.plot(cmap="Blues", values_format="d")
plt.title("Matriz de Confusão - GaussianNB")
plt.show()
