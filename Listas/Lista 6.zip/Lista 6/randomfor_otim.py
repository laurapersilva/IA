import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, 
                             roc_auc_score, average_precision_score,
                             ConfusionMatrixDisplay, classification_report)

from skopt import BayesSearchCV
from skopt.space import Integer, Categorical, Real
from sklearn.tree import export_graphviz
import graphviz


CSV_PATH = "bank.csv"   # <-- ajuste aqui
bank_data = pd.read_csv(CSV_PATH)

bank_data['y'] = bank_data['y'].map({'no': 0, 'yes': 1})

# Mantemos colunas categóricas como strings para o OneHotEncoder (não mapeie 'default' para 0/1)
X = bank_data.drop(columns=['y'])
y = bank_data['y']

# Identifica colunas categóricas e numéricas
cat_cols = X.select_dtypes(include=['object', 'category']).columns.tolist()
num_cols = X.select_dtypes(exclude=['object', 'category']).columns.tolist()



preprocess = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore', sparse=False), cat_cols),
        ('num', 'passthrough', num_cols)
    ]
)

rf = RandomForestClassifier(
    n_jobs=-1,
    random_state=42
)

pipe = Pipeline(steps=[
    ('prep', preprocess),
    ('model', rf)
])


X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)


search_spaces = {
    'model__n_estimators': Integer(300, 1200),
    'model__max_depth': Integer(4, 30),                     
    'model__min_samples_split': Integer(2, 20),
    'model__min_samples_leaf': Integer(1, 10),
    'model__max_features': Categorical(['sqrt', 'log2', 0.5, 0.7, 0.9]),
    'model__bootstrap': Categorical([True, False]),
    'model__class_weight': Categorical(['balanced', 'balanced_subsample', None])
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

bayes = BayesSearchCV(
    estimator=pipe,
    search_spaces=search_spaces,
    n_iter=50,                     
    scoring='roc_auc',             # bom para classe desbalanceada; pode ser 'average_precision' ou 'f1'
    cv=cv,
    n_jobs=-1,
    verbose=1,
    random_state=42
)

#Treino com otimização bayesiana
bayes.fit(X_train, y_train)

print("\n=== Melhor combinação de hiperparâmetros (validação cruzada) ===")
print(bayes.best_params_)
print(f"Melhor score CV ({bayes.scoring}): {bayes.best_score_:.4f}")

best_clf = bayes.best_estimator_

# Avaliação no teste
y_prob = best_clf.predict_proba(X_test)[:, 1]
y_pred = (y_prob >= 0.5).astype(int)   # threshold padrão 0.5

print("\n=== Métricas no conjunto de teste ===")
print(f"ROC AUC:               {roc_auc_score(y_test, y_prob):.4f}")
print(f"PR AUC (Avg Precision):{average_precision_score(y_test, y_prob):.4f}")
print(f"Accuracy:              {accuracy_score(y_test, y_pred):.4f}")
print(f"Precision:             {precision_score(y_test, y_pred, zero_division=0):.4f}")
print(f"Recall:                {recall_score(y_test, y_pred, zero_division=0):.4f}")
print(f"F1:                    {f1_score(y_test, y_pred, zero_division=0):.4f}")
print("\nClassification report:\n", classification_report(y_test, y_pred, zero_division=0))

ConfusionMatrixDisplay.from_predictions(y_test, y_pred, normalize='true')
plt.title("Matriz de Confusão (normalizada)")
plt.show()


# Recupera nomes pós-OneHot
feature_names = best_clf.named_steps['prep'].get_feature_names_out()
importances = best_clf.named_steps['model'].feature_importances_
imp_df = (pd.DataFrame({'feature': feature_names, 'importance': importances})
            .sort_values('importance', ascending=False)
            .head(15))
print("\nTop 15 importâncias de atributos:\n", imp_df)



try:
    tree = best_clf.named_steps['model'].estimators_[0]
    dot = export_graphviz(
        tree,
        out_file=None,
        feature_names=feature_names,
        class_names=['no', 'yes'],
        filled=True,
        rounded=True,
        max_depth=2,
        impurity=False,
        proportion=True
    )
    graph = graphviz.Source(dot)
    display(graph)
except Exception as e:
    print("Não foi possível renderizar a árvore. Dica: instale o Graphviz no sistema. Erro:", e)
